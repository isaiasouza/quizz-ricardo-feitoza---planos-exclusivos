import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { TrendingUp, Lock, Zap } from 'lucide-react';

interface GrowthChartProps {
  currentQuestionIndex: number;
  totalQuestions: number;
}

const GrowthChart: React.FC<GrowthChartProps> = ({ currentQuestionIndex, totalQuestions }) => {
  const [chartData, setChartData] = useState<any[]>([]);
  const [displayValue, setDisplayValue] = useState(160000);
  const [growthPercent, setGrowthPercent] = useState(0);
  const [animatePulse, setAnimatePulse] = useState(false);

  // Dados fixos baseados na especificação exata
  const baseData = [
    { step: 1, value: 160000, percent: 0 },
    { step: 2, value: 180000, percent: 12.5 },
    { step: 3, value: 200000, percent: 25 },
    { step: 4, value: 220000, percent: 37.5 },
    { step: 5, value: 240000, percent: 50 },
    { step: 6, value: 260000, percent: 62.5 },
    { step: 7, value: 280000, percent: 75 },
    { step: 8, value: 288000, percent: 80 },
    { step: 9, value: 288000, percent: 80 },
    { step: 10, value: 288000, percent: 80 },
  ];

  useEffect(() => {
    // Trigger pulse effect on update
    setAnimatePulse(true);
    const timer = setTimeout(() => setAnimatePulse(false), 1000);

    // Calcular índice seguro (0 a 9)
    const safeIndex = Math.min(Math.max(0, currentQuestionIndex), baseData.length - 1);
    const currentStepData = baseData[safeIndex];

    // Preparar dados para o gráfico:
    // Mostramos todos os pontos no eixo X, mas o valor 'y' só existe até o ponto atual
    // para criar o efeito da linha "crescendo"
    const generatedData = baseData.map((s, i) => ({
      name: `Q${s.step}`,
      // Se o índice for menor ou igual ao atual, mostra o valor. Senão, null (linha não desenhada)
      value: i <= safeIndex ? s.value : null, 
      fullValue: s.value, // Valor real para tooltip mesmo se não desenhado (opcional)
      percent: s.percent,
      isCurrent: i === safeIndex
    })).filter(item => item.value !== null); // Recharts lida melhor filtrando ou usando connectNulls=false

    setChartData(generatedData);
    setGrowthPercent(currentStepData.percent);

    // Animação do contador numérico
    let start = displayValue;
    const end = currentStepData.value;
    
    const animDuration = 1200;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / animDuration, 1);
      const ease = 1 - Math.pow(1 - progress, 3); // Cubic ease out
      
      const nextVal = Math.floor(start + (end - start) * ease);
      setDisplayValue(nextVal);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);

    return () => clearTimeout(timer);
  }, [currentQuestionIndex]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { 
      style: 'currency', 
      currency: 'BRL', 
      maximumFractionDigits: 0 
    }).format(val);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-brand-gray border-2 border-brand-gold p-3 rounded-lg shadow-[0_5px_15px_rgba(0,0,0,0.5)]">
          <p className="text-brand-gold font-heading font-bold text-xs mb-1">{label}</p>
          <p className="text-white font-bold text-lg mb-1">
            {formatCurrency(data.value)}
          </p>
          <p className="text-brand-orange text-xs font-bold">
            +{data.percent}% Crescimento
          </p>
        </div>
      );
    }
    return null;
  };

  // Custom Dot para o gráfico
  const CustomDot = (props: any) => {
    const { cx, cy, payload } = props;
    if (payload.isCurrent) {
        return (
            <svg x={cx - 6} y={cy - 6} width={12} height={12} fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="6" cy="6" r="6" fill="#FF6B35" />
                <circle cx="6" cy="6" r="6" stroke="#D4AF37" strokeWidth="2" className="animate-ping" opacity="0.5"/>
            </svg>
        );
    }
    return (
        <circle cx={cx} cy={cy} r={4} fill="#FF6B35" stroke="#1a1a1a" strokeWidth={1} />
    );
  };

  return (
    <div className="w-full h-auto min-h-[350px] bg-gradient-to-b from-[#1a1a1a] to-[#2d2d2d] rounded-xl border-l-4 border-brand-gold shadow-[0_10px_40px_rgba(212,175,55,0.15)] p-6 flex flex-col relative overflow-hidden transition-all duration-500 hover:shadow-[0_15px_50px_rgba(212,175,55,0.25)]">
      
      {/* Efeito de Grid Background sutil */}
      <div className="absolute inset-0 opacity-5 pointer-events-none" 
           style={{backgroundImage: 'linear-gradient(#333 1px, transparent 1px), linear-gradient(90deg, #333 1px, transparent 1px)', backgroundSize: '20px 20px'}}>
      </div>

      {/* Cabeçalho */}
      <div className="text-center mb-6 relative z-10">
        <h3 className="text-white font-heading font-bold text-sm uppercase tracking-widest opacity-80 mb-3">
          Seu Potencial de Faturamento
        </h3>
        
        <div className="flex flex-col items-center justify-center relative">
          <div className={`text-3xl md:text-4xl font-heading font-black text-brand-gold drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] transition-transform duration-300 ${animatePulse ? 'scale-105 brightness-110' : 'scale-100'}`}>
            {formatCurrency(displayValue)}
          </div>
          
          <div className={`mt-2 transition-all duration-700 ${growthPercent > 0 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
             <div className="inline-flex items-center gap-1.5 bg-[#FF6B35]/10 border border-[#FF6B35]/30 px-3 py-1 rounded-full">
               <TrendingUp className="w-4 h-4 text-[#FF6B35]" />
               <span className="text-[#FF6B35] font-bold text-sm">+{growthPercent}% Crescimento</span>
             </div>
          </div>
        </div>
      </div>

      {/* Gráfico */}
      <div className="h-[220px] w-full relative z-10 -ml-2 flex-grow">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2d2d2d" vertical={false} />
            <XAxis 
              dataKey="name" 
              stroke="#666" 
              tick={{fontSize: 10, fill: '#666'}} 
              tickLine={false}
              axisLine={false}
              dy={10}
            />
            <YAxis 
              stroke="#666" 
              tick={{fontSize: 10, fill: '#666'}} 
              tickFormatter={(val) => `${val/1000}k`}
              tickLine={false}
              axisLine={false}
              domain={[140000, 'auto']}
            />
            <Tooltip content={<CustomTooltip />} cursor={{stroke: '#2d2d2d', strokeWidth: 1}} />
            <Line 
              type="monotone" 
              dataKey="value" 
              stroke="#D4AF37" 
              strokeWidth={3}
              dot={<CustomDot />}
              activeDot={{ r: 8, fill: "#FF6B35", stroke: "#D4AF37", strokeWidth: 2 }}
              animationDuration={1000}
              animationEasing="ease-out"
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Footer / Progresso */}
      <div className="mt-4 pt-4 border-t border-white/5 flex justify-between items-center text-xs text-gray-500 relative z-10">
         <div className="flex items-center gap-2">
            <div className="relative w-8 h-8 rounded-full border-2 border-brand-gold/30 flex items-center justify-center">
               <span className="text-brand-gold font-bold">{Math.min(currentQuestionIndex + 1, 10)}</span>
            </div>
            <span className="uppercase tracking-wider font-medium">de {totalQuestions} Perguntas</span>
         </div>
         
         {growthPercent >= 80 && (
           <div className="flex items-center gap-1 text-brand-success animate-pulse">
             <Zap className="w-4 h-4" />
             <span className="font-bold">Potencial Máximo!</span>
           </div>
         )}
      </div>

      {/* Badge de "Método Validado" */}
      {currentQuestionIndex > 2 && (
        <div className="absolute top-4 right-4 animate-fade-in">
          <Lock className="w-4 h-4 text-brand-gold opacity-40" />
        </div>
      )}

    </div>
  );
};

export default GrowthChart;