
import React, { useState, useEffect } from 'react';
import { ResultContent, ResultType } from '../types';
import { 
  Check, Star, Shield, ArrowRight, Crown, 
  Play, X, Clock, AlertTriangle, Download, Smartphone, Lock, ChevronDown, ChevronUp, Rocket
} from 'lucide-react';

interface ResultCardProps {
  result: ResultContent;
  resultType: ResultType;
  barberName?: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, barberName }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [showStickyCta, setShowStickyCta] = useState(false);
  const [timeLeft, setTimeLeft] = useState({ m: 14, s: 59 });
  
  // Estado para controlar o atraso do conteúdo (VSL Delay)
  const [showDelayedContent, setShowDelayedContent] = useState(false);

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  // Timer de 5 minutos para liberar o conteúdo
  useEffect(() => {
    const DELAY_TIME = 5 * 60 * 1000; // 5 minutos em milissegundos
    
    const timer = setTimeout(() => {
      setShowDelayedContent(true);
    }, DELAY_TIME);

    return () => clearTimeout(timer);
  }, []);

  // Lógica do Sticky CTA (Só aparece se o conteúdo estiver liberado e houver scroll)
  useEffect(() => {
    const handleScroll = () => {
      if (showDelayedContent) {
        setShowStickyCta(window.scrollY > 400);
      } else {
        setShowStickyCta(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [showDelayedContent]);

  // Countdown Timer Logic (Barra de Urgência)
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.s === 0) {
          if (prev.m === 0) return prev;
          return { m: prev.m - 1, s: 59 };
        }
        return { m: prev.m, s: prev.s - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (val: number) => val < 10 ? `0${val}` : val;

  const faqs = [
    { q: "Funciona para quem trabalha sozinho?", a: "Sim! O método 'Euquipe' é um dos pilares. Você aprende a maximizar seu lucro por hora trabalhada, sem precisar contratar ninguém se não quiser." },
    { q: "O acesso é vitalício?", a: "Sim! Você paga uma vez (ou parcela em 12x) e tem acesso para sempre, incluindo todas as atualizações futuras do material." },
    { q: "Como recebo o material?", a: "Imediatamente após a aprovação do pagamento, você recebe um email com login e senha da nossa área de membros exclusiva." },
    { q: "Tenho garantia?", a: "Garantia incondicional de 7 dias. Se achar que não é para você, devolvemos 100% do valor sem perguntas." }
  ];

  const testimonials = [
    { name: "Felipe S.", role: "Barbeiro Solo", text: "Eu cobrava R$ 25 e trabalhava 12h por dia. Hoje cobro R$ 60 e tenho 40 assinantes. Mudou minha vida.", gain: "+120% Lucro" },
    { name: "Barbearia Vintage", role: "Equipe de 4", text: "Implementamos o Plano Ouro e vendemos 15 no primeiro dia. R$ 4.500 de caixa num dia fraco.", gain: "R$ 4.5k/dia" },
    { name: "André Luiz", role: "Gestor", text: "O script de vendas é surreal. O cliente acha que está levando vantagem em pagar mais caro. Genial.", gain: "Fidelização" },
  ];

  const bonuses = [
    { title: "Precificação Automática", price: "R$ 97", icon: <FileText className="w-5 h-5 text-blue-500" /> },
    { title: "Contratos VIP Editáveis", price: "R$ 147", icon: <FileText className="w-5 h-5 text-purple-500" /> },
    { title: "Scripts de Venda", price: "R$ 97", icon: <Smartphone className="w-5 h-5 text-green-500" /> },
  ];

  return (
    <div className="w-full bg-white animate-fade-in pb-24 md:pb-0 font-sans">
      
      {/* Sticky Mobile CTA - Condicionado ao Delay */}
      {showDelayedContent && (
        <div className={`fixed bottom-0 left-0 w-full bg-white border-t border-gray-200 p-3 z-50 md:hidden shadow-[0_-4px_20px_rgba(0,0,0,0.15)] transition-transform duration-300 ${showStickyCta ? 'translate-y-0' : 'translate-y-full'}`}>
          <div className="flex items-center justify-between gap-3">
            <div className="flex flex-col pl-2">
               <span className="text-[10px] text-gray-400 uppercase tracking-wide font-bold">Apenas</span>
               <div className="flex items-baseline gap-1">
                 <span className="text-sm font-bold text-brand-dark">12x</span>
                 <span className="text-xl font-black text-green-600 leading-none">R$ 19,66</span>
               </div>
            </div>
            <button className="flex-1 bg-brand-success hover:bg-green-600 text-white font-bold py-3 px-2 rounded-lg shadow-lg flex items-center justify-center gap-1 text-sm uppercase tracking-wide animate-pulse">
              Quero Agora <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Urgency Bar - Condicionado ao Delay */}
      {showDelayedContent && (
        <div className="bg-red-600 text-white py-2 px-4 text-center text-xs md:text-base font-bold flex items-center justify-center gap-2 animate-slide-in-top sticky top-0 z-40 md:relative">
          <Clock className="w-3 h-3 md:w-4 md:h-4 animate-pulse" />
          <span>OFERTA EXPIRA EM: {formatTime(timeLeft.m)}:{formatTime(timeLeft.s)}</span>
        </div>
      )}

      {/* Hero Section Personalized (Sempre visível) */}
      <section className="relative bg-brand-dark text-white py-8 md:py-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.1),transparent_70%)]"></div>
        <div className="container mx-auto px-4 relative z-10">
          
          <div className="max-w-4xl mx-auto text-center mb-6 md:mb-8">
            <div className="inline-flex items-center gap-2 bg-brand-success/20 border border-brand-success/40 rounded-full px-3 py-1 md:px-4 md:py-1.5 text-brand-success text-[10px] md:text-sm font-bold mb-4 md:mb-6 uppercase tracking-widest">
              <Check className="w-3 h-3 md:w-4 md:h-4" /> Análise Concluída para {barberName}
            </div>
            <h1 className="text-2xl md:text-5xl font-heading font-bold leading-tight mb-3 md:mb-4">
              Não aumente seus clientes. <br/>
              <span className="text-brand-gold">Aumente o valor deles.</span>
            </h1>
            <p className="text-gray-300 text-sm md:text-xl max-w-2xl mx-auto leading-relaxed">
              O plano exato para implementar assinaturas e dobrar o lucro da <strong className="text-white">{barberName || 'sua barbearia'}</strong> em 60 dias.
            </p>
          </div>

          {/* VSL / Video Area */}
          <div className="max-w-4xl mx-auto relative">
             <div className="relative aspect-video bg-gray-800 rounded-xl border-2 border-brand-gold/30 shadow-[0_0_40px_rgba(0,0,0,0.5)] group cursor-pointer overflow-hidden">
                  <div className="absolute inset-0 bg-cover bg-center opacity-50" style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1621605815971-fbc98d6d4e85?auto=format&fit=crop&q=80")' }}></div>
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all"></div>
                  
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 md:w-20 md:h-20 bg-brand-orange rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,107,53,0.6)] z-10 animate-pulse-slow">
                      <Play className="w-6 h-6 md:w-8 md:h-8 text-white ml-1" />
                    </div>
                  </div>

                  <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black to-transparent p-4 md:p-6 pt-16 md:pt-20">
                     <p className="text-white font-bold text-base md:text-xl">Estudo de Caso: Ricardo Feitoza</p>
                     <div className="flex items-center gap-2 text-brand-gold text-xs md:text-sm">
                       <AlertTriangle className="w-3 h-3 md:w-4 md:h-4" />
                       <span>Assista antes que saia do ar</span>
                     </div>
                  </div>
             </div>
             
             {/* Button under video for mobile - Condicionado ao Delay */}
             {showDelayedContent && (
                <div className="mt-6 text-center md:hidden animate-fade-in">
                   <button className="w-full bg-brand-success hover:bg-green-600 text-white font-heading font-bold text-lg py-4 px-6 rounded-lg shadow-[0_4px_14px_0_rgba(39,174,96,0.39)] flex items-center justify-center gap-2 animate-bounce-slow">
                      QUERO ACESSAR AGORA <ArrowRight className="w-5 h-5" />
                   </button>
                   <p className="text-xs text-gray-500 mt-2">Menos de R$ 0,65 por dia</p>
                </div>
             )}
          </div>
        </div>
      </section>

      {/* Wrapper para todo o conteúdo atrasado */}
      {showDelayedContent && (
        <div className="animate-fade-in">
          
          {/* Problem/Solution */}
          <section className="py-8 md:py-12 bg-gray-50">
            <div className="container mx-auto px-4">
              <h2 className="text-xl md:text-3xl font-heading font-bold text-center text-brand-dark mb-6 md:mb-10 leading-snug">
                Por que você trabalha tanto e <span className="text-red-600 underline decoration-red-300">lucra pouco</span>?
              </h2>

              <div className="grid md:grid-cols-2 gap-6 md:gap-8 max-w-5xl mx-auto">
                {/* The Problem */}
                <div className="bg-white p-5 md:p-8 rounded-2xl shadow-sm border-l-4 border-red-500 opacity-90">
                   <div className="flex items-center gap-3 mb-4 md:mb-6">
                     <div className="bg-red-100 p-2 rounded-full"><X className="w-5 h-5 md:w-6 md:h-6 text-red-600" /></div>
                     <h3 className="font-bold text-lg md:text-xl text-gray-800">O Ciclo da Falência</h3>
                   </div>
                   <ul className="space-y-3 md:space-y-4 text-sm md:text-base text-gray-600">
                     <li className="flex gap-3"><span className="text-red-500 font-bold">✗</span> Você cobra barato pra atrair cliente</li>
                     <li className="flex gap-3"><span className="text-red-500 font-bold">✗</span> A agenda lota, mas as contas não fecham</li>
                     <li className="flex gap-3"><span className="text-red-500 font-bold">✗</span> Cliente te troca por R$ 5,00 a menos</li>
                     <li className="flex gap-3"><span className="text-red-500 font-bold">✗</span> Você vira escravo da cadeira</li>
                   </ul>
                </div>

                {/* The Solution */}
                <div className="bg-white p-5 md:p-8 rounded-2xl shadow-xl border-2 border-brand-success transform md:-translate-y-4 relative">
                   <div className="absolute -top-3 md:-top-4 left-1/2 -translate-x-1/2 bg-brand-success text-white px-3 py-1 md:px-4 md:py-1 rounded-full text-[10px] md:text-xs font-bold uppercase tracking-wider shadow-lg whitespace-nowrap">
                     O Novo Modelo
                   </div>
                   <div className="flex items-center gap-3 mb-4 md:mb-6 mt-2 md:mt-0">
                     <div className="bg-green-100 p-2 rounded-full"><Check className="w-5 h-5 md:w-6 md:h-6 text-brand-success" /></div>
                     <h3 className="font-bold text-lg md:text-xl text-brand-dark">O Método Planos Exclusivos</h3>
                   </div>
                   <ul className="space-y-3 md:space-y-4 text-sm md:text-base text-gray-700">
                     <li className="flex gap-3"><span className="text-brand-success font-bold">✓</span> Receita recorrente (mesmo se chover)</li>
                     <li className="flex gap-3"><span className="text-brand-success font-bold">✓</span> Clientes fiéis pagando Ticket Alto</li>
                     <li className="flex gap-3"><span className="text-brand-success font-bold">✓</span> Previsibilidade de caixa no dia 01</li>
                     <li className="flex gap-3"><span className="text-brand-success font-bold">✓</span> Valorização da sua hora técnica</li>
                   </ul>
                </div>
              </div>
            </div>
          </section>

          {/* The "Stack" - Total Value */}
          <section className="py-10 md:py-14 bg-white">
            <div className="container mx-auto px-4 max-w-4xl">
              <div className="text-center mb-8 md:mb-10">
                <h2 className="text-2xl md:text-3xl font-heading font-bold text-brand-dark">Isso é tudo que você recebe</h2>
                <p className="text-gray-500 text-sm md:text-base mt-2">Acesso imediato e vitalício a todo o ecossistema.</p>
              </div>

              <div className="space-y-3 md:space-y-4">
                {/* Core Product */}
                <div className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 gap-3 md:gap-0">
                   <div className="flex items-center gap-4">
                     <div className="bg-brand-dark p-3 rounded-lg text-brand-gold flex-shrink-0"><Rocket className="w-6 h-6" /></div>
                     <div>
                       <h4 className="font-bold text-base md:text-lg text-brand-dark leading-tight">Treinamento Planos Exclusivos</h4>
                       <p className="text-xs md:text-sm text-gray-500 mt-1">O passo a passo completo em vídeo.</p>
                     </div>
                   </div>
                   <div className="text-right border-t pt-2 md:border-0 md:pt-0 mt-2 md:mt-0 flex justify-between md:block items-center">
                     <span className="block text-xs text-gray-400 uppercase">Valor Real</span>
                     <span className="font-bold text-gray-700">R$ 497,00</span>
                   </div>
                </div>

                {/* Bonuses */}
                {bonuses.map((bonus, i) => (
                  <div key={i} className="flex items-center justify-between p-3 md:p-4 bg-white rounded-lg border border-dashed border-brand-gold/50 shadow-sm">
                     <div className="flex items-center gap-3 md:gap-4">
                       <div className="bg-brand-light p-2 md:p-3 rounded-lg flex-shrink-0">{bonus.icon}</div>
                       <div>
                         <div className="flex flex-wrap items-center gap-2">
                           <span className="bg-brand-gold text-brand-dark text-[9px] md:text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">Bônus</span>
                           <h4 className="font-bold text-sm md:text-base text-brand-dark leading-tight">{bonus.title}</h4>
                         </div>
                       </div>
                     </div>
                     <div className="text-right pl-2">
                       <span className="block text-[10px] md:text-xs text-gray-400 uppercase md:mb-1">Valor</span>
                       <span className="font-bold text-sm md:text-base text-gray-700 whitespace-nowrap">{bonus.price}</span>
                     </div>
                  </div>
                ))}
              </div>

              {/* Total Value Summary */}
              <div className="mt-6 md:mt-8 p-4 md:p-6 bg-gray-100 rounded-xl text-center md:text-right flex flex-col md:block items-center">
                <p className="text-gray-500 text-xs md:text-sm uppercase tracking-wider mb-1">Valor Total se comprado separado</p>
                <p className="text-2xl md:text-3xl font-bold text-gray-400 line-through">R$ 838,00</p>
              </div>
            </div>
          </section>

          {/* The Offer / Pricing Anchor */}
          <section className="py-10 md:py-16 bg-brand-dark text-white relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
            
            <div className="container mx-auto px-4 relative z-10 max-w-3xl text-center">
              <h2 className="text-2xl md:text-4xl font-heading font-bold mb-3 md:mb-4 leading-tight">
                Oferta Especial para <span className="text-brand-gold">{barberName || 'Você'}</span>
              </h2>
              <p className="text-gray-300 mb-8 md:mb-10 text-sm md:text-base">
                Você não vai pagar R$ 838,00. Nem R$ 497,00.<br/>
                Sua oportunidade de mudar o jogo custa menos que uma pizza.
              </p>

              <div className="bg-white text-brand-dark rounded-2xl p-6 md:p-12 shadow-[0_0_50px_rgba(212,175,55,0.3)] border-4 border-brand-gold relative">
                 <div className="absolute -top-4 md:-top-5 left-1/2 -translate-x-1/2 bg-red-600 text-white px-4 py-1.5 md:px-6 md:py-2 rounded-lg font-bold text-sm md:text-base uppercase tracking-wider shadow-md animate-pulse whitespace-nowrap">
                   75% de Desconto Hoje
                 </div>

                 <div className="mb-4 md:mb-6 mt-4 md:mt-0">
                   <span className="text-gray-400 text-base md:text-lg line-through font-medium">De R$ 497,00</span>
                 </div>

                 <div className="flex flex-col items-center justify-center mb-6 md:mb-8">
                   <span className="text-base md:text-lg font-bold text-gray-600 uppercase mb-2">Por Apenas</span>
                   <div className="flex items-end gap-1 md:gap-2 leading-none">
                     <span className="text-2xl md:text-4xl font-bold text-brand-dark mb-1 md:mb-2">12x</span>
                     <span className="text-5xl md:text-8xl font-black text-brand-success tracking-tighter">19,66</span>
                   </div>
                   <span className="text-brand-orange font-bold mt-3 md:mt-4 text-base md:text-lg">ou R$ 197,00 à vista</span>
                 </div>

                 <button className="w-full bg-brand-success hover:bg-green-600 text-white font-heading font-bold text-lg md:text-2xl py-4 md:py-5 px-4 md:px-8 rounded-xl shadow-xl hover:-translate-y-1 transition-all flex items-center justify-center gap-2 md:gap-3 mb-4 md:mb-6">
                    QUERO MEU PLANO <ArrowRight className="w-6 h-6 md:w-8 md:h-8" />
                 </button>

                 <div className="flex flex-wrap justify-center gap-3 md:gap-8 text-xs md:text-sm text-gray-500">
                   <div className="flex items-center gap-1.5">
                     <Shield className="w-4 h-4 text-brand-gold" />
                     <span>Garantia de 7 Dias</span>
                   </div>
                   <div className="flex items-center gap-1.5">
                     <Lock className="w-4 h-4 text-brand-gold" />
                     <span>Pagamento Seguro</span>
                   </div>
                   <div className="flex items-center gap-1.5">
                     <Download className="w-4 h-4 text-brand-gold" />
                     <span>Acesso Imediato</span>
                   </div>
                 </div>
              </div>
            </div>
          </section>

          {/* Testimonials Carousel - Optimized for Mobile Peeking */}
          <section className="py-8 md:py-12 bg-gray-100">
            <div className="container mx-auto px-4">
              <h2 className="text-xl md:text-2xl font-heading font-bold text-center mb-6 md:mb-8 text-brand-dark">
                Resultados de quem aplicou
              </h2>
              
              <div className="flex overflow-x-auto snap-x snap-mandatory gap-4 pb-6 hide-scrollbar -mx-4 px-4 md:mx-0 md:grid md:grid-cols-3 md:gap-6 md:overflow-visible">
                {testimonials.map((t, i) => (
                  <div key={i} className="snap-center min-w-[85vw] md:min-w-0 bg-white border border-gray-200 p-5 md:p-6 rounded-xl shadow-sm relative flex flex-col h-full">
                    <div className="flex gap-1 mb-3 md:mb-4">
                      {[...Array(5)].map((_, j) => <Star key={j} className="w-3 h-3 md:w-4 md:h-4 text-brand-gold fill-brand-gold" />)}
                    </div>
                    <p className="text-sm md:text-base text-gray-600 italic mb-4 md:mb-6 flex-grow">"{t.text}"</p>
                    <div className="flex items-center justify-between border-t border-gray-100 pt-3 md:pt-4 mt-auto">
                      <div>
                        <p className="font-bold text-sm md:text-base text-brand-dark">{t.name}</p>
                        <p className="text-[10px] md:text-xs text-gray-400">{t.role}</p>
                      </div>
                      <div className="bg-green-100 text-green-700 px-2 py-1 rounded text-[10px] md:text-xs font-bold">
                        {t.gain}
                      </div>
                    </div>
                  </div>
                ))}
                {/* Spacer for mobile scroll */}
                <div className="min-w-[2vw] md:hidden"></div>
              </div>
            </div>
          </section>

          {/* FAQ Accordion */}
          <section className="py-8 md:py-12 bg-white">
            <div className="container mx-auto px-4 max-w-2xl">
              <h2 className="text-xl md:text-2xl font-heading font-bold text-center mb-6 md:mb-8 text-brand-dark">
                 Perguntas Frequentes
              </h2>
              <div className="space-y-3">
                {faqs.map((faq, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg overflow-hidden bg-gray-50">
                     <button 
                       onClick={() => toggleFaq(index)}
                       className="w-full px-4 py-3 md:px-5 md:py-4 text-left flex justify-between items-center hover:bg-gray-100 transition-colors"
                     >
                        <span className="font-bold text-brand-dark text-sm md:text-base pr-2">{faq.q}</span>
                        {openFaq === index ? <ChevronUp className="w-5 h-5 text-gray-400 shrink-0"/> : <ChevronDown className="w-5 h-5 text-gray-400 shrink-0"/>}
                     </button>
                     {openFaq === index && (
                       <div className="px-4 py-3 md:px-5 md:py-4 bg-white text-gray-600 text-sm leading-relaxed border-t border-gray-100 animate-slide-up">
                         {faq.a}
                       </div>
                     )}
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Final Branding Footer */}
          <div className="py-6 md:py-8 bg-brand-dark text-center border-t border-gray-800">
             <div className="flex items-center justify-center gap-2 mb-4 opacity-50 grayscale hover:grayscale-0 transition-all">
                 <Crown className="w-5 h-5 md:w-6 md:h-6 text-brand-gold" />
                 <span className="text-brand-gold font-heading font-bold text-sm md:text-base">RICARDO FEITOZA</span>
             </div>
             <p className="text-gray-600 text-[10px] md:text-xs">Este site não faz parte do site do Facebook ou Facebook Inc.</p>
          </div>
        </div>
      )}

    </div>
  );
};

// Helper for icon missing in imports
const FileText = (props: any) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
);

export default ResultCard;
