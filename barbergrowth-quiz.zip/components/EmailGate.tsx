import React, { useState } from 'react';
import { Mail, Lock, ArrowRight } from 'lucide-react';

interface EmailGateProps {
  onSubmit: (email: string) => void;
}

const EmailGate: React.FC<EmailGateProps> = ({ onSubmit }) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Por favor, insira um email válido.');
      return;
    }
    onSubmit(email);
  };

  return (
    <div className="max-w-lg mx-auto px-6 py-12 w-full animate-fade-in">
      <div className="text-center mb-8">
         <div className="w-20 h-20 bg-brand-gold/10 rounded-full flex items-center justify-center mx-auto mb-6 border-2 border-brand-gold">
            <Mail className="w-10 h-10 text-brand-gold" />
         </div>
         <h2 className="text-3xl font-heading font-bold text-brand-dark mb-2">
           Antes de começar...
         </h2>
         <p className="text-brand-textLight font-sans text-lg">
           Deixe seu email para receber seu resultado personalizado
         </p>
      </div>

      <div className="bg-white p-8 rounded-xl shadow-xl border border-gray-100">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError('');
              }}
              placeholder="seu@email.com"
              className="w-full px-5 py-4 rounded-lg bg-white border-2 border-brand-gold/50 text-brand-dark placeholder-gray-400 focus:border-brand-orange focus:ring-4 focus:ring-brand-orange/10 outline-none transition-all text-lg"
            />
            {error && <p className="text-red-500 text-sm mt-2 text-left flex items-center gap-1"><span className="font-bold">!</span> {error}</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-brand-orange hover:bg-brand-orangeDark text-white font-heading font-bold py-4 px-6 rounded-lg shadow-[0_5px_15px_rgba(255,107,53,0.3)] hover:shadow-[0_8px_20px_rgba(255,107,53,0.4)] transition-all duration-300 flex items-center justify-center gap-2 text-lg transform hover:-translate-y-0.5"
          >
            CONTINUAR
            <ArrowRight className="w-5 h-5" />
          </button>
        </form>

        <div className="mt-6 flex items-center justify-center gap-2 text-sm text-gray-400">
          <Lock className="w-3 h-3" />
          <span>Seus dados são 100% privados</span>
        </div>
      </div>
    </div>
  );
};

export default EmailGate;