
import React, { useEffect, useState, useRef } from 'react';
import { Question, OptionType } from '../types';
import { Target, Lightbulb, Banknote, Rocket, ArrowRight, TrendingUp, Check, Scissors, Zap, Crown, SprayCan, User, Users, Building2 } from 'lucide-react';

interface QuestionCardProps {
  question: Question;
  totalQuestions: number;
  currentIndex: number;
  onAnswer: (answer: any) => void;
  savedData?: any;
}

const getStageIcon = (index: number) => {
  if (index < 2) return <Target className="w-6 h-6 md:w-8 md:h-8 text-brand-orange" />;
  if (index < 5) return <Banknote className="w-6 h-6 md:w-8 md:h-8 text-brand-gold" />;
  if (index < 8) return <Lightbulb className="w-6 h-6 md:w-8 md:h-8 text-brand-orange" />;
  if (index < 10) return <TrendingUp className="w-6 h-6 md:w-8 md:h-8 text-brand-gold" />;
  return <Rocket className="w-6 h-6 md:w-8 md:h-8 text-brand-orange" />;
};

const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  totalQuestions,
  currentIndex,
  onAnswer,
  savedData
}) => {
  const [selectedOption, setSelectedOption] = useState<OptionType | string | null>(null);
  const [multiSelected, setMultiSelected] = useState<string[]>([]);
  const [textValue, setTextValue] = useState('');
  const [rangeValue, setRangeValue] = useState<number>(0);
  const [isLocked, setIsLocked] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const progressPercentage = ((currentIndex + 1) / totalQuestions) * 100;

  useEffect(() => {
    setSelectedOption(null);
    setMultiSelected([]);
    setTextValue('');
    setIsLocked(false);
    
    if (question.rangeConfig) {
      const mid = question.rangeConfig.min + ((question.rangeConfig.max - question.rangeConfig.min) / 2);
      setRangeValue(Math.floor(mid));
    }

    if (question.type === 'text') {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [question]); 

  const handleOptionClick = (id: OptionType | string) => {
    if (isLocked) return;
    setIsLocked(true);
    setSelectedOption(id);
    setTimeout(() => onAnswer(id), 300);
  };

  const handleMultiSelect = (id: string) => {
    if (multiSelected.includes(id)) {
      setMultiSelected(prev => prev.filter(item => item !== id));
    } else {
      setMultiSelected(prev => [...prev, id]);
    }
  };

  const submitMultiSelect = () => {
    if (multiSelected.length === 0) return;
    onAnswer(multiSelected);
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textValue.trim()) return;
    onAnswer(textValue);
  };

  const handleRangeSubmit = () => {
    onAnswer(rangeValue);
  };

  const handleRangeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRangeValue(Number(e.target.value));
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 }).format(val);
  };

  const renderIcon = (iconName: string) => {
    switch(iconName) {
      case 'Scissors': return <Scissors className="w-6 h-6 md:w-8 md:h-8" />;
      case 'Zap': return <Zap className="w-6 h-6 md:w-8 md:h-8" />;
      case 'Crown': return <Crown className="w-6 h-6 md:w-8 md:h-8" />;
      case 'SprayCan': return <SprayCan className="w-6 h-6 md:w-8 md:h-8" />;
      case 'User': return <User className="w-6 h-6 md:w-8 md:h-8" />;
      case 'Users': return <Users className="w-6 h-6 md:w-8 md:h-8" />;
      case 'Building2': return <Building2 className="w-6 h-6 md:w-8 md:h-8" />;
      default: return null;
    }
  };

  const renderInput = () => {
    switch (question.type) {
      case 'text':
        return (
          <form onSubmit={handleTextSubmit} className="mt-6 animate-fade-in w-full max-w-md mx-auto">
            <input
              ref={inputRef}
              type="text"
              value={textValue}
              onChange={(e) => setTextValue(e.target.value)}
              placeholder={question.placeholder}
              className="w-full bg-gray-50 border-b-2 border-brand-gold text-xl md:text-2xl py-4 px-2 focus:outline-none focus:border-brand-orange transition-colors text-center font-heading font-bold text-brand-dark rounded-t-lg"
            />
            <button
              type="submit"
              disabled={!textValue.trim()}
              className="mt-8 w-full bg-brand-dark text-white py-4 rounded-lg font-bold uppercase tracking-wide hover:bg-brand-orange active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              Continuar <ArrowRight className="w-5 h-5" />
            </button>
          </form>
        );

      case 'choice':
        return (
          <div className="space-y-3 mt-4 md:mt-6 w-full max-w-lg mx-auto">
            {question.options?.map((option, idx) => {
              const isSelected = selectedOption === option.id;
              return (
                <div 
                  key={String(option.id)}
                  onClick={() => handleOptionClick(option.id)}
                  style={{ animationDelay: `${idx * 75}ms` }}
                  className={`
                    group relative overflow-hidden cursor-pointer
                    bg-white border-2 rounded-lg p-3 md:p-5 transition-all duration-200 ease-out animate-slide-up
                    hover:shadow-md active:scale-[0.98]
                    ${isSelected 
                      ? 'border-brand-orange bg-orange-50 shadow-lg transform scale-[1.01]' 
                      : isLocked 
                        ? 'border-gray-100 opacity-50 cursor-not-allowed'
                        : 'border-gray-200 hover:border-brand-gold hover:bg-brand-gold/5'
                    }
                  `}
                >
                  <div className="flex items-center">
                    <div className={`
                      flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mr-3 md:mr-4 font-heading font-bold text-sm transition-colors
                      ${isSelected ? 'bg-brand-orange text-white' : 'bg-brand-dark text-brand-gold group-hover:bg-brand-gold group-hover:text-white'}
                    `}>
                      {String(option.id)}
                    </div>
                    <span className="text-brand-text font-sans text-sm md:text-lg leading-snug font-medium">
                      {option.text}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        );

      case 'multiselect':
        return (
          <div className="mt-4 md:mt-6 w-full max-w-2xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {question.options?.map((option, idx) => {
                const isSelected = multiSelected.includes(String(option.id));
                return (
                  <div 
                    key={String(option.id)}
                    onClick={() => handleMultiSelect(String(option.id))}
                    style={{ animationDelay: `${idx * 75}ms` }}
                    className={`
                      cursor-pointer border-2 rounded-lg p-3 md:p-4 transition-all duration-150 animate-slide-up flex items-center justify-between
                      active:scale-[0.98] touch-manipulation
                      ${isSelected 
                        ? 'border-brand-orange bg-orange-50 shadow-sm' 
                        : 'border-gray-200 hover:border-brand-gold/50'
                      }
                    `}
                  >
                    <span className="font-bold text-brand-dark text-sm md:text-base">{option.text}</span>
                    <div className={`w-6 h-6 rounded border flex items-center justify-center transition-colors ${isSelected ? 'bg-brand-orange border-brand-orange' : 'border-gray-300'}`}>
                      {isSelected && <Check className="w-4 h-4 text-white" />}
                    </div>
                  </div>
                );
              })}
            </div>
            <button
              onClick={submitMultiSelect}
              disabled={multiSelected.length === 0}
              className="mt-6 md:mt-8 w-full bg-brand-dark text-white py-4 rounded-lg font-bold uppercase tracking-wide hover:bg-brand-orange active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              Confirmar <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        );

      case 'image-choice':
      case 'team-size':
        return (
          <div className="grid grid-cols-2 gap-3 md:gap-4 mt-4 md:mt-6 w-full max-w-xl mx-auto">
            {question.options?.map((option, idx) => {
              const isSelected = selectedOption === option.id;
              return (
                <div 
                  key={String(option.id)}
                  onClick={() => handleOptionClick(option.id)}
                  style={{ animationDelay: `${idx * 75}ms` }}
                  className={`
                    cursor-pointer border-2 rounded-xl p-4 md:p-6 flex flex-col items-center text-center gap-3 md:gap-4 transition-all duration-200 animate-slide-up
                    active:scale-[0.97] hover:shadow-lg touch-manipulation
                    ${isSelected 
                      ? 'border-brand-orange bg-orange-50 scale-105 shadow-lg' 
                      : isLocked
                        ? 'opacity-50'
                        : 'border-gray-200 hover:border-brand-gold'
                    }
                  `}
                >
                  <div className={`transition-transform duration-300 ${isSelected ? 'text-brand-orange scale-110' : 'text-brand-dark group-hover:scale-110'}`}>
                    {renderIcon(option.icon)}
                  </div>
                  <span className="font-bold text-brand-dark text-sm md:text-base">{option.text}</span>
                </div>
              );
            })}
          </div>
        );

      case 'range':
      case 'simulator':
        return (
          <div className="mt-6 md:mt-8 animate-fade-in w-full max-w-lg mx-auto">
            <div className="bg-gray-50 p-4 md:p-6 rounded-xl border border-gray-200 mb-6">
              <div className="flex justify-between items-end mb-4">
                 <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">
                   Selecione o valor:
                 </label>
                 <span className="text-xl md:text-3xl font-heading font-bold text-brand-dark">
                   {formatCurrency(rangeValue)}
                 </span>
              </div>

              <div className="relative h-12 flex items-center">
                <input 
                  type="range" 
                  min={question.rangeConfig?.min}
                  max={question.rangeConfig?.max}
                  step={question.rangeConfig?.step}
                  value={rangeValue}
                  onChange={handleRangeChange}
                  className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-orange focus:outline-none z-20 relative touch-none"
                />
                <div 
                  className="absolute left-0 top-1/2 -translate-y-1/2 h-3 bg-brand-orange rounded-l-lg pointer-events-none z-10"
                  style={{ width: `${((rangeValue - (question.rangeConfig?.min || 0)) / ((question.rangeConfig?.max || 100) - (question.rangeConfig?.min || 0))) * 100}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between text-xs text-gray-400 mt-2 font-bold uppercase tracking-wider">
                <span>{question.rangeConfig?.labelLow}</span>
                <span>{question.rangeConfig?.labelHigh}</span>
              </div>
            </div>

            <button
              onClick={handleRangeSubmit}
              className="w-full bg-brand-dark text-white py-4 rounded-lg font-bold uppercase tracking-wide hover:bg-brand-orange active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl hover:-translate-y-1 group"
            >
              Confirmar
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        );
    }
  };

  return (
    <div className="w-full h-full flex flex-col animate-fade-in">
      {/* Progress Bar Mobile Only (Top) */}
      <div className="md:hidden w-full bg-gray-200 h-1.5 mb-4 relative rounded-full overflow-hidden">
        <div 
          className="bg-brand-gold h-full transition-all duration-500 ease-out"
          style={{ width: `${progressPercentage}%` }}
        ></div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl md:shadow-2xl border border-gray-100 overflow-hidden flex-grow flex flex-col">
        <div className="bg-gray-50 p-4 md:p-6 border-b border-gray-100 flex justify-between items-center">
            <div className="flex items-center gap-3">
               <div className="p-2 bg-white rounded-lg border border-brand-gold/30 shadow-sm text-brand-dark">
                 {getStageIcon(currentIndex)}
               </div>
               <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                 Pergunta {currentIndex + 1} de {totalQuestions}
               </span>
            </div>
            {/* Progress Text Desktop */}
            <span className="hidden md:block font-heading font-black text-brand-gold/20 text-4xl">
              {currentIndex + 1 < 10 ? `0${currentIndex + 1}` : currentIndex + 1}
            </span>
        </div>

        <div className="p-4 md:p-10 flex-grow flex flex-col justify-center items-center text-center">
           <h2 className="text-xl md:text-3xl font-heading font-bold text-brand-dark mb-2 md:mb-3 leading-tight max-w-3xl">
             {question.text}
           </h2>
           {question.subText && (
             <p className="text-gray-500 font-medium text-sm md:text-base mb-4 md:mb-6 max-w-2xl">{question.subText}</p>
           )}

           {renderInput()}
        </div>

        <div className="bg-gray-50 p-3 md:p-4 text-center border-t border-gray-100 mt-auto">
           <p className="text-brand-textLight italic text-xs md:text-sm flex items-center justify-center gap-2">
             <span className="text-brand-gold flex-shrink-0"><Lightbulb className="w-4 h-4" /></span> {question.microCopy}
           </p>
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;
