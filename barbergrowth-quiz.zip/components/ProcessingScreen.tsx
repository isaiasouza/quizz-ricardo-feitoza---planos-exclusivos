
import React, { useEffect, useState, useRef } from 'react';
import { CheckCircle2, Loader2, ShieldCheck, Cpu } from 'lucide-react';

interface ProcessingScreenProps {
  loadingText: string;
  steps?: string[];
  onComplete?: () => void;
}

const ProcessingScreen: React.FC<ProcessingScreenProps> = ({ 
  loadingText, 
  steps = ["Conectando ao banco de dados...", "Analisando métricas...", "Gerando relatório final..."],
  onComplete
}) => {
  const [progress, setProgress] = useState(0);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Refs para controle de animação sem re-renderizações desnecessárias
  const requestRef = useRef<number | null>(null);
  const startTimeRef = useRef<number | null>(null);

  // Configurações Visuais
  // Responsividade é tratada via CSS Classes no SVG pai, mas o raio base é usado para cálculo
  const RADIUS = 70;
  const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
  const DURATION = 4000; // 4 segundos totais

  // Função de Easing para movimento natural (começa rápido, termina suave)
  const easeOutQuart = (x: number): number => {
    return 1 - Math.pow(1 - x, 4);
  };

  useEffect(() => {
    const animate = (time: number) => {
      if (startTimeRef.current === null) {
        startTimeRef.current = time;
      }
      
      const timeElapsed = time - startTimeRef.current;
      const rawProgress = Math.min(timeElapsed / DURATION, 1);
      
      // Aplica o easing
      const easedProgress = easeOutQuart(rawProgress) * 100;
      
      setProgress(easedProgress);

      // Lógica de Passos (Steps)
      // Divide o progresso total (100%) pelo número de passos
      const totalSteps = steps.length;
      const stepThreshold = 100 / totalSteps;
      
      // Calcula qual passo deve estar ativo baseado na porcentagem atual
      let activeIndex = Math.floor(easedProgress / stepThreshold);
      if (activeIndex >= totalSteps) activeIndex = totalSteps - 1;
      
      setCurrentStepIndex(activeIndex);

      if (timeElapsed < DURATION) {
        requestRef.current = requestAnimationFrame(animate);
      } else {
        // Finalização
        setIsSuccess(true);
        setProgress(100);
        setTimeout(() => {
          if (onComplete) onComplete();
        }, 800); // Pequena pausa para o usuário ver o sucesso (100%)
      }
    };

    requestRef.current = requestAnimationFrame(animate);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [steps.length, DURATION, onComplete]);

  // Cálculo do Stroke Dashoffset para o SVG
  const strokeDashoffset = CIRCUMFERENCE - (progress / 100) * CIRCUMFERENCE;

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] w-full max-w-lg mx-auto px-6 animate-fade-in">
      
      {/* Área do Gráfico Circular */}
      <div className="relative mb-8 md:mb-10">
        {/* SVG Circular - Reduzido no Mobile (w-40) / Normal Desktop (w-48) */}
        <div className="relative w-40 h-40 md:w-48 md:h-48 flex items-center justify-center transition-all">
          <svg className="w-full h-full transform -rotate-90 drop-shadow-2xl" viewBox="0 0 160 160">
             {/* Ajustado viewBox para garantir escala correta do raio 70 (centro 80,80) */}
            {/* Círculo de Fundo (Trilho) */}
            <circle
              cx="80"
              cy="80"
              r={RADIUS}
              stroke="#f3f4f6" // gray-100
              strokeWidth="8"
              fill="transparent"
            />
            {/* Círculo de Progresso (Animado) */}
            <circle
              cx="80"
              cy="80"
              r={RADIUS}
              stroke={isSuccess ? "#27AE60" : "#D4AF37"} // Success Green ou Brand Gold
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={CIRCUMFERENCE}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              className="transition-all duration-100 ease-out"
            />
          </svg>

          {/* Conteúdo Central (Icone + Porcentagem) */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-brand-dark">
             <div className="mb-1 md:mb-2 transition-all duration-300 transform">
               {isSuccess ? (
                 <CheckCircle2 className="w-10 h-10 md:w-12 md:h-12 text-brand-success animate-bounce-slow" />
               ) : (
                 <Cpu className="w-10 h-10 md:w-12 md:h-12 text-brand-gold animate-pulse" />
               )}
             </div>
             <span className="text-2xl md:text-3xl font-heading font-black tracking-tight">
               {Math.round(progress)}%
             </span>
          </div>

          {/* Anel Externo Decorativo (Gira lentamente) */}
          {!isSuccess && (
             <div className="absolute inset-0 rounded-full border border-dashed border-brand-gold/30 animate-spin-slow pointer-events-none scale-110"></div>
          )}
        </div>
      </div>

      {/* Texto Principal */}
      <div className="h-16 flex flex-col items-center justify-start mb-6 md:mb-8 text-center">
        <h2 className="text-lg md:text-2xl font-heading font-bold text-brand-dark animate-pulse">
          {isSuccess ? "Concluído!" : loadingText}
        </h2>
        <p className="text-gray-400 text-xs md:text-sm mt-1">
           {isSuccess ? "Redirecionando..." : "Por favor, aguarde..."}
        </p>
      </div>

      {/* Lista de Passos (Checklist) */}
      <div className="w-full max-w-sm bg-white rounded-xl p-4 border border-gray-100 shadow-sm space-y-3">
        {steps.map((step, index) => {
          // Lógica de Estado do Passo
          const isActive = index === currentStepIndex && !isSuccess;
          const isCompleted = index < currentStepIndex || isSuccess;
          const isPending = index > currentStepIndex && !isSuccess;

          return (
            <div 
              key={index}
              className={`flex items-center gap-3 transition-all duration-500 ${
                isPending ? 'opacity-40 grayscale' : 'opacity-100'
              }`}
            >
              {/* Ícone indicador */}
              <div className={`
                w-5 h-5 md:w-6 md:h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300
                ${isCompleted ? 'bg-brand-success text-white scale-100' : ''}
                ${isActive ? 'bg-brand-orange text-white scale-110 shadow-[0_0_10px_rgba(255,107,53,0.5)]' : ''}
                ${isPending ? 'bg-gray-200 text-gray-400' : ''}
              `}>
                {isCompleted ? (
                  <CheckCircle2 className="w-3 h-3 md:w-4 md:h-4" />
                ) : isActive ? (
                  <Loader2 className="w-3 h-3 md:w-4 md:h-4 animate-spin" />
                ) : (
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-gray-400 rounded-full" />
                )}
              </div>

              {/* Texto do Passo */}
              <span className={`font-medium text-xs md:text-base transition-colors ${
                isActive ? 'text-brand-dark font-bold' : isCompleted ? 'text-gray-600' : 'text-gray-400'
              }`}>
                {step}
              </span>
            </div>
          );
        })}
      </div>
      
      <div className="mt-8 text-[10px] text-gray-400 uppercase tracking-widest flex items-center gap-2 opacity-70">
        <ShieldCheck className="w-3 h-3" />
        Processamento Seguro
      </div>

    </div>
  );
};

export default ProcessingScreen;
