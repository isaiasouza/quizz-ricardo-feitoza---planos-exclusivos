
import React from 'react';
import { Play, Clock } from 'lucide-react';

interface IntroProps {
  onStart: () => void;
}

const Intro: React.FC<IntroProps> = ({ onStart }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-4 md:py-8 text-center relative animate-fade-in flex flex-col justify-center min-h-[85vh] md:min-h-0 pb-24 md:pb-8">
      
      {/* Main Content */}
      <div className="relative z-10">
        <h1 className="text-3xl md:text-5xl font-heading font-bold text-white mb-2 md:mb-4 leading-tight drop-shadow-lg">
          Descubra Seu Potencial de Faturamento
        </h1>
        
        <h2 className="text-xl md:text-4xl font-heading font-semibold text-brand-gold mb-6 md:mb-12 tracking-wide drop-shadow-[0_2px_10px_rgba(212,175,55,0.3)]">
          Com Planos Exclusivos
        </h2>

        {/* Intro Box */}
        <div className="bg-white/95 backdrop-blur-sm border-2 border-brand-gold p-5 md:p-8 rounded-lg shadow-[0_10px_30px_rgba(0,0,0,0.2)] max-w-2xl mx-auto mb-8 md:mb-12 transform transition-all hover:scale-[1.01] animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            <div className="flex-shrink-0">
               <div className="w-14 h-14 md:w-16 md:h-16 bg-brand-dark rounded-full flex items-center justify-center relative group cursor-pointer">
                 <div className="absolute inset-0 bg-brand-orange rounded-full opacity-20 animate-ping"></div>
                 <Play className="w-6 h-6 md:w-8 md:h-8 text-brand-orange fill-brand-orange relative z-10 ml-1" />
               </div>
            </div>
            <div className="text-center md:text-left">
               <p className="text-brand-text font-sans text-sm md:text-lg leading-relaxed">
                 Responda 10 perguntas rápidas e receba um diagnóstico personalizado. Descubra se você pode aplicar a mesma estratégia que o <strong>Ricardo Feitoza</strong> usou para crescer 80% sem aumentar clientes.
               </p>
            </div>
          </div>
        </div>

        {/* Mobile Sticky Footer with Gradient for Visibility */}
        <div className="flex flex-col items-center gap-3 fixed bottom-0 left-0 right-0 p-6 md:relative md:bottom-auto md:p-0 z-20 bg-gradient-to-t from-brand-dark via-brand-dark/95 to-transparent md:from-transparent md:via-transparent pt-12 md:pt-0">
          <button
            onClick={onStart}
            className="w-full md:w-auto bg-brand-orange hover:bg-brand-orangeDark text-white font-heading font-bold text-lg py-4 px-12 rounded-md shadow-[0_5px_15px_rgba(255,107,53,0.3)] hover:shadow-[0_8px_25px_rgba(255,107,53,0.5)] active:scale-95 transition-all duration-200 uppercase tracking-wide"
          >
            Começar Quiz
          </button>
          
          <div className="flex items-center gap-2 text-brand-gold font-medium animate-pulse-slow md:mt-4 text-xs md:text-base bg-brand-dark/50 md:bg-transparent px-3 py-1 rounded-full backdrop-blur-md md:backdrop-blur-none">
            <Clock className="w-4 h-4 md:w-5 md:h-5" />
            <span>Tempo estimado: 3 minutos</span>
          </div>
        </div>
      </div>
      
      {/* Decorative Background Elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[150%] h-[150%] bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.08)_0%,rgba(0,0,0,0)_70%)] -z-0 pointer-events-none"></div>
    </div>
  );
};

export default Intro;
